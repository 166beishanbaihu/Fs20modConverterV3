package com.fs20mod.converter.mod

import android.content.Context
import com.fs20mod.converter.debug.RunLog
import com.fs20mod.converter.storage.LocalFs
import com.fs20mod.converter.storage.ModFs
import com.fs20mod.converter.tools.ImageThumb
import java.io.File

/** modDesc 中 descVersion 对应的游戏判定；留好扩展点。 */
object GameVersions {
    private val table = listOf(
        40..59 to "FS19",
    )

    /** 后续可按需加入 FS22 / FS25 区间。 */
    fun labelOf(descVersion: Int?): String {
        if (descVersion == null) return "未知"
        table.forEach { (range, label) ->
            if (descVersion in range) return label
        }
        return "未知（descVersion=$descVersion）"
    }
}

data class VehicleInfo(
    val xmlName: String,
    val type: String,
    val imageRef: String?,
    val imagePath: String?,
    val imageUrl: String?,
    val price: String,
    val brand: String,
    val brandLogoUrl: String?,
    val i3dRef: String?,
    val i3dExists: Boolean,
    val ddsRefs: Int,
    val skippedRefs: Int,
)

data class ModInfo(
    val rootName: String,
    val descVersion: String,
    val gameLabel: String,
    val modVersion: String,
    val title: String,
    val vehicles: List<VehicleInfo>,
)

/** 读取 mod 结构：所有读取都走 ModFs，本地目录与 SAF 原文件夹一视同仁。 */
object ModReader {

    private val descVersionRe = Regex("""descVersion\s*=\s*"([^"]*)"""")
    private val versionRe = Regex("""<version>([^<]*)</version>""")
    private val titleRe = Regex("""<title>\s*<en>([^<]*)</en>""")
    private val storeItemRe = Regex("""<storeItem\b[^>]*?xmlFilename\s*=\s*"([^"]+)"""")
    private val typeRe = Regex("""<vehicle\b[^>]*?\btype\s*=\s*"([^"]*)"""")
    private val imageRe = Regex("""<image>([^<]*)</image>""")
    private val priceRe = Regex("""<price>([^<]*)</price>""")
    private val brandRe = Regex("""<brand>([^<]*)</brand>""")
    private val filenameRe = Regex("""<filename>([^<]*)</filename>""")

    fun inspect(context: Context, root: File): ModInfo? = inspect(context, LocalFs(root))

    fun inspect(context: Context, fs: ModFs): ModInfo? {
        RunLog.step("READER", "开始解析 ${fs.label}")
        val modDescPath = findModDesc(fs) ?: run {
            RunLog.w("READER", "未找到 modDesc.xml")
            return null
        }
        RunLog.step("READER", "modDesc=$modDescPath")

        val text = fs.readText(modDescPath) ?: return null

        val descVersion = descVersionRe.find(text)?.groupValues?.get(1)?.trim()
        val gameLabel = GameVersions.labelOf(descVersion?.toIntOrNull())
        RunLog.step("READER", "descVersion=$descVersion → $gameLabel")

        val modVersion = versionRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val title = titleRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        RunLog.step("READER", "MOD 版本=$modVersion 标题=$title")

        val refs = storeItemRe.findAll(text).map { it.groupValues[1].trim() }.distinct().toList()
        RunLog.step("READER", "storeItem 共 ${refs.size} 条（去重后）")

        val vehicles = refs.map { ref ->
            val vehiclePath = locate(fs, ref)
            RunLog.step("READER", "storeItem xmlFilename=$ref → ${vehiclePath ?: "未找到"}")
            inspectVehicle(context, fs, ref, vehiclePath)
        }

        return ModInfo(
            rootName = fs.label,
            descVersion = descVersion.orEmpty(),
            gameLabel = gameLabel,
            modVersion = modVersion,
            title = title,
            vehicles = vehicles,
        )
    }

    /** 图片扩展名兜底：XML 写 .dds 但实际文件是 .png（或反之）时自动关联。 */
    private val imageExts = listOf("png", "jpg", "jpeg", "dds", "tga")

    /** .xml 后缀大小写不敏感，前缀必须精确匹配；同目录优先，最后按文件名 / 图片扩展名兜底。 */
    fun locate(fs: ModFs, ref: String, from: String? = null): String? {
        val normalized = ref.replace('\\', '/').removePrefix("./")
        val all = fs.list()

        all.firstOrNull { it == normalized }?.let { return it }

        val target = normalized.substringAfterLast('/')
        val parentHint = from?.substringBeforeLast('/', "")?.takeIf { it.isNotEmpty() }
        val prefix = normalized.substringBeforeLast('/', "")

        val sameName = sequence {
            if (parentHint != null) yieldAll(
                all.filter {
                    it.substringBeforeLast('/', "") == parentHint &&
                        it.substringAfterLast('/').equals(target, true)
                }
            )
            if (prefix.isNotEmpty()) yieldAll(
                all.filter {
                    it.substringBeforeLast('/', "").equals(prefix, true) &&
                        it.substringAfterLast('/').equals(target, true)
                }
            )
            yieldAll(all.filter { it.substringAfterLast('/').equals(target, true) })
        }
        sameName.firstOrNull()?.let { return it }

        // 扩展名不符（.dds ↔ .png/.jpg）：按主体名再找一次，同目录 / 同前缀优先
        val base = target.substringBeforeLast('.', target)
        val refExt = target.substringAfterLast('.', "").lowercase()
        if (base != target && refExt in imageExts) {
            val byBase = all.filter { path ->
                val name = path.substringAfterLast('/')
                val stem = name.substringBeforeLast('.', name)
                val ext = name.substringAfterLast('.', "").lowercase()
                stem.equals(base, true) && ext in imageExts
            }
            byBase.firstOrNull { it.substringBeforeLast('/', "") == parentHint }?.let {
                RunLog.step("READER", "引用 $ref 实际命中 $it（扩展名自动关联）")
                return it
            }
            byBase.firstOrNull {
                prefix.isNotEmpty() && it.substringBeforeLast('/', "").equals(prefix, true)
            }?.let {
                RunLog.step("READER", "引用 $ref 实际命中 $it（扩展名自动关联）")
                return it
            }
            byBase.firstOrNull()?.let {
                RunLog.step("READER", "引用 $ref 实际命中 $it（扩展名自动关联）")
                return it
            }
        }
        return null
    }

    private fun inspectVehicle(
        context: Context,
        fs: ModFs,
        ref: String,
        path: String?,
    ): VehicleInfo {
        if (path == null) {
            RunLog.w("READER", "车辆文件缺失：$ref")
            return VehicleInfo(ref, "", null, null, null, "", "", null, null, false, 0, 0)
        }
        val text = fs.readText(path).orEmpty()

        val type = typeRe.find(text)?.groupValues?.get(1).orEmpty()
        val imageRef = imageRe.find(text)?.groupValues?.get(1)?.trim()
        val price = priceRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val brand = brandRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val i3dRef = filenameRe.find(text)?.groupValues?.get(1)?.trim()

        RunLog.step("READER", "车辆 $path: type=$type brand=$brand price=$price image=$imageRef i3d=$i3dRef")

        val imagePath = imageRef?.let { image -> locate(fs, image, from = path) }
        val imageUrl = imagePath?.let { ImageThumb.dataUrl(fs, it, 420) }
        val logoUrl = brand.takeIf { it.isNotBlank() }?.let { findBrandLogo(context, fs, it) }

        val i3dPath = i3dRef?.let { locate(fs, it, from = path) }
        val i3dCheck = i3dPath?.let { analyseI3d(fs, it) } ?: I3dCheck(0, 0, false)

        return VehicleInfo(
            xmlName = ref,
            type = type,
            imageRef = imageRef,
            imagePath = imagePath,
            imageUrl = imageUrl,
            price = price,
            brand = brand,
            brandLogoUrl = logoUrl,
            i3dRef = i3dRef,
            i3dExists = i3dCheck.exists,
            ddsRefs = i3dCheck.ddsRefs,
            skippedRefs = i3dCheck.skippedRefs,
        )
    }

    data class I3dCheck(val ddsRefs: Int, val skippedRefs: Int, val exists: Boolean = true)

    /** 统计 i3d 内 .dds 引用，以及以 $ 开头被跳过的行。 */
    fun analyseI3d(fs: ModFs, path: String): I3dCheck {
        val text = fs.readText(path, Charsets.ISO_8859_1) ?: return I3dCheck(0, 0, false)
        var dds = 0
        var skipped = 0
        val blocks = Regex("""<Files>([\s\S]*?)</Files>""").findAll(text)
        blocks.forEach { block ->
            Regex("""filename\s*=\s*"([^"]*)"""").findAll(block.groupValues[1]).forEach { m ->
                val v = m.groupValues[1].trim()
                if (v.startsWith("$")) {
                    skipped++
                } else if (v.endsWith(".dds", true)) {
                    dds++
                }
            }
        }
        return I3dCheck(dds, skipped, true)
    }

    /**
     * 品牌图标：优先用内置品牌包（assets/brands/brand_<id>.png，不区分大小写），
     * 内置包没有时再回落到 mod 自带图标。
     */
    private fun findBrandLogo(context: Context, fs: ModFs, brand: String): String? {
        BrandIcons.dataUrl(context, brand)?.let { return it }

        val id = brand.lowercase().removePrefix("brand_").replace(" ", "")
        val candidate = fs.list().firstOrNull { path ->
            val ext = path.substringAfterLast('.', "").lowercase()
            if (ext !in setOf("png", "jpg", "jpeg", "dds")) return@firstOrNull false
            val name = path.substringAfterLast('/').substringBeforeLast('.').lowercase()
            name == "brand_$id" || name == id || name.endsWith("_$id")
        }
        if (candidate != null) {
            val local = ImageThumb.dataUrl(fs, candidate, 160)
            if (local != null) return local
        }

        // 品牌包里没有、mod 里也没有：用 LIZARD 作为默认图标
        RunLog.step("READER", "品牌 $brand 无图标，使用默认 LIZARD")
        return BrandIcons.dataUrl(context, DEFAULT_BRAND)
    }

    /** 找不到品牌图标时的默认品牌。 */
    private const val DEFAULT_BRAND = "LIZARD"

    private fun findModDesc(fs: ModFs): String? =
        fs.list().firstOrNull { it.substringAfterLast('/').equals("modDesc.xml", true) }
}

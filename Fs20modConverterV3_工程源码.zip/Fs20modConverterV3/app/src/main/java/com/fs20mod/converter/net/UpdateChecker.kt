package com.fs20mod.converter.net

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import com.fs20mod.converter.debug.RunLog
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * 云更新：从 GitHub 发布仓库读取 version.json，
 * 有新版本就下载 APK 交给系统安装器（App 内完成，不依赖手动下载）。
 */
object UpdateChecker {

    /** 发布仓库的清单地址（每次发版同步更新）。 */
    private const val MANIFEST_URL =
        "https://raw.githubusercontent.com/166beishanbaihu/Fs20modConverterV3/main/version.json"

    data class Info(
        val versionCode: Long,
        val versionName: String,
        val url: String,
        val size: Long,
        val notes: String,
    )

    fun hasUpdate(currentCode: Long, info: Info?): Boolean =
        info != null && info.versionCode > currentCode && info.url.isNotBlank()

    /** 拉清单。网络失败返回 null，不抛异常。 */
    fun fetch(): Info? = runCatching {
        RunLog.step("UPDATE", "读取清单 $MANIFEST_URL")
        val text = http(MANIFEST_URL) ?: return null
        val json = JSONObject(text)
        Info(
            versionCode = json.optLong("versionCode"),
            versionName = json.optString("versionName"),
            url = json.optString("url"),
            size = json.optLong("size"),
            notes = json.optString("notes"),
        ).also { RunLog.step("UPDATE", "清单版本 ${it.versionName}(${it.versionCode})") }
    }.onFailure { RunLog.w("UPDATE", "读取清单失败：${it.message}") }.getOrNull()

    private fun http(url: String): String? {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Fs20modConverter")
            conn.setRequestProperty("Accept", "application/json")
            conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            conn.disconnect()
        }
    }

    /** 下载到 filesDir/update/，边下边回调百分比。 */
    fun download(context: Context, info: Info, onProgress: (Int) -> Unit): File? = runCatching {
        val dir = File(context.filesDir, "update").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val dest = File(dir, "update-${info.versionName}.apk")

        val conn = URL(info.url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Fs20modConverter")
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: info.size
            var read = 0L
            conn.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(8192)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        out.write(buf, 0, n)
                        read += n
                        if (total > 0) onProgress(((read * 100) / total).toInt().coerceIn(0, 100))
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        RunLog.step("UPDATE", "下载完成 ${dest.length()} 字节 → ${dest.name}")
        dest.takeIf { it.length() > 100_000 } ?: return null
    }.onFailure { RunLog.e("UPDATE", "下载失败", it) }.getOrNull()

    /** 交给系统安装器；未授予「安装未知应用」时先跳授权页。 */
    fun install(context: Context, apk: File): Boolean = runCatching {
        if (!context.packageManager.canRequestPackageInstalls()) {
            RunLog.w("UPDATE", "未授予安装未知应用权限，跳转授权页")
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        RunLog.step("UPDATE", "已提交系统安装器")
        true
    }.onFailure { RunLog.e("UPDATE", "调起安装失败", it) }.getOrDefault(false)
}

/* Fs20mod 转换器 —— 页面逻辑 */

const $ = (id) => document.getElementById(id);

let mode = "folder";
let currentPage = "convert";

/* ---------- 原生桥回调 ---------- */
window.App = {
  onMod(info) {
    // 桥接可能传字符串，兜住两种形态；渲染失败也要恢复按钮，避免卡在"读取中"
    if (typeof info === "string") {
      try { info = JSON.parse(info); } catch (e) { logLine("error", "结果解析失败: " + e); info = {}; }
    }
    try {
      $("modCard").classList.remove("hidden");
      $("modTitle").textContent = info.title || info.rootName || "mod";
      $("gameBadge").textContent = info.gameLabel || "未知";
      $("modVersion").textContent = info.modVersion || "-";
      renderVehicles(Array.isArray(info.vehicles) ? info.vehicles : []);
      $("startBtn").disabled = false;
    } catch (e) {
      logLine("error", "渲染失败: " + e);
    } finally {
      setBusy(false);
    }
  },

  onBusy(payload) {
    setBusy(true, payload && payload.msg ? payload.msg : "处理中…");
  },

  onError(payload) {
    setBusy(false);
    logLine("error", (payload && payload.msg) || "出错了");
    $("progressCard").classList.remove("hidden");
  },

  onProgress(payload) {
    $("progressCard").classList.remove("hidden");
    $("phaseText").textContent = payload.phase || "处理中";
    $("ratioText").textContent = (payload.ratio || 0) + "%";
    $("barFill").style.width = Math.max(0, Math.min(100, payload.ratio || 0)) + "%";
    $("noteText").textContent = payload.note || "";
  },

  onLog(payload) {
    logLine(payload.level || "info", payload.msg || "");
  },

  onDone(payload) {
    $("progressCard").classList.remove("hidden");
    $("doneCard").classList.remove("hidden");
    const ok = !!payload.ok;
    const inPlace = !!payload.inPlace;
    $("doneTitle").textContent = ok ? (inPlace ? "已就地转换" : "转换完成") : "转换失败";
    $("doneDetails").innerHTML = kvRows(payload.details || {});
    const warn = (payload.warnings || []).map(w => `<div class="note">· ${esc(w)}</div>`).join("");
    $("doneWarn").innerHTML = warn;
    // 就地模式结果已在原文件夹，没有 zip 可导出
    $("exportBtn").classList.toggle("hidden", !ok || inPlace);
    if (ok) {
      $("barFill").style.width = "100%";
      $("ratioText").textContent = "100%";
      $("phaseText").textContent = "完成";
    }
    setBusy(false);
  },

  onExport(payload) {
    alert((payload && payload.msg) || "导出完成");
  },

  onCover(payload) {
    const p = payload || {};
    $("viewerName").textContent = p.ref || "封面";
    if (p.url) {
      $("viewerImg").src = p.url;
      $("viewerImg").classList.remove("hidden");
      $("viewerMsg").textContent = "";
    } else {
      $("viewerImg").classList.add("hidden");
      $("viewerMsg").textContent = p.msg || "无法解码这张封面（可能是 BC4/BC5 等 DDS 压缩格式）";
    }
  },

  onUpdate(payload) {
    const p = payload || {};
    $("updCurrent").textContent = p.current || "-";
    $("updLatest").textContent = p.latest || "-";
    $("updBadge").textContent = !p.ok ? "检查失败" : (p.hasUpdate ? "有新版本" : "已是最新");
    $("updNote").textContent = p.notes || p.msg || "";
    $("updInstallBtn").disabled = !p.hasUpdate;
    $("updCheckBtn").textContent = "检查更新";
  },

  onUpdateProgress(payload) {
    const p = payload || {};
    $("updNote").textContent = p.msg || "";
    if (p.done) $("updCheckBtn").textContent = "检查更新";
  },

  handleBack() {
    if (currentPage !== "convert") {
      go("convert");
      return true;
    }
    return false;
  },
};

/* ---------- 交互 ---------- */
function setBusy(busy, text) {
  $("pickBtn").disabled = busy;
  $("startBtn").disabled = busy || $("modCard").classList.contains("hidden");
  $("pickBtn").textContent = busy ? (text || "处理中…") : (mode === "folder" ? "选择 mod 文件夹" : "选择 zip 压缩包");
}

$("modeSeg").addEventListener("click", (e) => {
  const btn = e.target.closest(".seg-btn");
  if (!btn) return;
  mode = btn.dataset.mode;
  document.querySelectorAll("#modeSeg .seg-btn").forEach(b => b.classList.toggle("active", b === btn));
  $("pickBtn").textContent = mode === "folder" ? "选择 mod 文件夹" : "选择 zip 压缩包";
  $("outputNameWrap").classList.toggle("hidden", mode === "folder");
  $("modeNote").textContent = mode === "folder"
    ? "文件夹模式直接在原文件夹上转换并覆盖，不复制、不生成 zip。"
    : "压缩包模式在缓存中解压转换，完成后生成 zip 供你导出。";
});

// 初始为文件夹模式：就地覆盖，不需要输出名
$("outputNameWrap").classList.add("hidden");

$("pickBtn").addEventListener("click", () => {
  if (mode === "folder") bridge.pickFolder();
  else bridge.pickArchive();
});

$("startBtn").addEventListener("click", () => {
  // 车辆重命名 / 标题前缀 / I3D 同步：固定开启，不在界面上暴露开关
  const config = {
    ddsToPng: $("optDds").checked,
    renameVehicles: true,
    rewriteTitle: true,
    syncI3d: true,
    keepOriginals: $("optBackup").checked,
    outputName: ($("outputName").value || "").trim(),
  };
  $("doneCard").classList.add("hidden");
  $("logBox").innerHTML = "";
  $("progressCard").classList.remove("hidden");
  $("phaseText").textContent = "准备";
  $("ratioText").textContent = "0%";
  $("barFill").style.width = "0%";
  setBusy(true, "转换中…");
  bridge.startConvert(JSON.stringify(config));
});

$("exportBtn").addEventListener("click", () => bridge.exportResult());

$("logRefreshBtn").addEventListener("click", loadRunLog);
$("logExportBtn").addEventListener("click", () => {
  try { bridge.exportLog(); } catch (e) {}
});

/* ---------- 封面查看器 ---------- */
function openCover(xmlName) {
  $("viewer").classList.remove("hidden");
  $("viewerImg").classList.add("hidden");
  $("viewerImg").removeAttribute("src");
  $("viewerName").textContent = "封面加载中…";
  $("viewerMsg").textContent = "";
  try { bridge.showCover(xmlName || ""); } catch (e) { $("viewerMsg").textContent = "调用失败"; }
}

function closeCover() {
  $("viewer").classList.add("hidden");
  $("viewerImg").removeAttribute("src");
}

$("vehList").addEventListener("click", (e) => {
  const thumb = e.target.closest(".thumb.clickable");
  if (!thumb) return;
  openCover(thumb.dataset.xml || "");
});

$("viewerClose").addEventListener("click", closeCover);
$("viewer").addEventListener("click", (e) => {
  if (e.target.id === "viewer" || e.target.classList.contains("viewer-body")) closeCover();
});

$("updCheckBtn").addEventListener("click", () => {
  $("updCheckBtn").textContent = "检查中…";
  $("updBadge").textContent = "检查中";
  try { bridge.checkUpdate(); } catch (e) { $("updBadge").textContent = "检查失败"; }
});

$("updInstallBtn").addEventListener("click", () => {
  $("updInstallBtn").disabled = true;
  $("updNote").textContent = "正在下载更新…";
  try { bridge.startUpdate(); } catch (e) { $("updNote").textContent = "启动下载失败"; }
});

$("repoBtn").addEventListener("click", () =>
  bridge.openRepo("https://github.com/166beishanbaihu/Fs20modConverterV3")
);

$("themeSeg").addEventListener("click", (e) => {
  const btn = e.target.closest(".seg-btn");
  if (!btn) return;
  document.querySelectorAll("#themeSeg .seg-btn").forEach(b => b.classList.toggle("active", b === btn));
  document.body.classList.toggle("light", btn.dataset.theme === "light");
  try { localStorage.setItem("theme", btn.dataset.theme); } catch (e) {}
});

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => go(tab.dataset.go));
});

function go(page) {
  currentPage = page;
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("show", p.dataset.page === page));
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.go === page));
  if (page === "settings") {
    ensureMeta();
    loadRunLog();
    // 进设置页自动检查一次，不必手动点
    if ($("updBadge").textContent === "未检查") {
      $("updBadge").textContent = "检查中";
      try { bridge.checkUpdate(); } catch (e) { $("updBadge").textContent = "检查失败"; }
    }
  }
}

/* ---------- 渲染 ---------- */
function renderVehicles(list) {
  const box = $("vehList");
  list = Array.isArray(list) ? list : [];
  if (!list.length) {
    box.innerHTML = `<div class="note">没有读到 storeItems 车辆</div>`;
    return;
  }
  box.innerHTML = list.map(v => {
    const thumb = v.imageUrl
      ? `<img src="${v.imageUrl}" alt="">`
      : `<span class="ph">${v.imageRef ? esc(v.imageRef) : "无封面"}</span>`;
    const logo = v.brandLogoUrl ? `<img src="${v.brandLogoUrl}" alt="">` : "";
    const brand = v.brand ? `<span class="veh-brand">${logo}${esc(v.brand)}</span>` : "";
    const stats = [
      "价格 " + (v.price || "-"),
      v.i3dRef ? "i3d " + v.i3dRef : "无 i3d",
      "dds " + (v.ddsRefs || 0),
      v.skippedRefs ? "跳过 " + v.skippedRefs : "",
    ].filter(Boolean).join(" · ");

    const clickable = !!v.imageRef;
    return `<div class="veh">
      <div class="thumb${clickable ? " clickable" : ""}" data-xml="${esc(v.xmlName || "")}">${thumb}${clickable ? '<span class="zoom">查看</span>' : ""}</div>
      <div class="veh-meta">
        <div class="veh-line1">
          <span class="veh-type">${esc(v.type || "vehicle")}</span>
          ${brand}
        </div>
        <div class="veh-xml">${esc(v.xmlName || "")}</div>
        <div class="veh-stats">${esc(stats)}</div>
      </div>
    </div>`;
  }).join("");
}

function kvRows(obj) {
  return Object.entries(obj).map(([k, v]) =>
    `<div class="kv"><span>${esc(k)}</span><b>${esc(String(v))}</b></div>`
  ).join("");
}

function logLine(level, msg) {
  const box = $("logBox");
  $("progressCard").classList.remove("hidden");
  const el = document.createElement("div");
  el.className = level === "error" ? "error" : level === "warn" ? "warn" : "";
  el.textContent = msg;
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
}

function loadRunLog() {
  try {
    const t = bridge.logTail(150);
    $("runLogBox").textContent = t || "暂无日志";
    $("runLogBox").scrollTop = $("runLogBox").scrollHeight;
  } catch (e) {
    $("runLogBox").textContent = "日志不可用（非 App 环境）";
  }
  try {
    const c = bridge.lastCrash();
    $("crashBox").innerHTML = c
      ? `<div class="note" style="margin:8px 0 4px">最近一次崩溃</div><div class="log">${esc(c.slice(0, 3000))}</div>`
      : "";
  } catch (e) {}
}

function ensureMeta() {
  try {
    const v = bridge.version();
    if (v) {
      $("ver").textContent = "v" + v;
      $("setVersion").textContent = v;
    }
  } catch (e) {}
}

function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/* 初始 */
(function init() {
  ensureMeta();
  try {
    const saved = localStorage.getItem("theme");
    if (saved === "light") {
      document.body.classList.add("light");
      document.querySelectorAll("#themeSeg .seg-btn").forEach(b =>
        b.classList.toggle("active", b.dataset.theme === "light"));
    }
  } catch (e) {}
})();
